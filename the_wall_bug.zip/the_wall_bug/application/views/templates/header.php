<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width">
        <meta name="description" content="The Wall - Final">
        <meta name="author" content="Karen Marie E. Igcasan">
        <link rel="stylesheet" href="<?=base_url();?>assets/css/home_style.css"/>
    </head>
    <body>
        
        