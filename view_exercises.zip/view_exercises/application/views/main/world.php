<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Exercises</title>
    <link rel="stylesheet" href="<?= base_url('assets/css/style.css') ?>">
</head>
<body>
    <main>
        <img src="<?= base_url('assets/images/taj.jpg') ?>" alt="taj">
        <img src="<?= base_url('assets/images/the-great-wall.jpg') ?>" alt="the great wall of china">
        <img src="<?= base_url('assets/images/pyramids.jpg') ?>" alt="pyramids">
    </main>
</body>
</html>